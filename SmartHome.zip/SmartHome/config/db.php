<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=db_yii2project',
    'username' => 'root',
    'password' => '159357',
    'charset' => 'utf8',
];
